# Set Cookie: No secure - No HttpOnly
This repository stores the source code for the Set Cookie: No secure - No HttpOnly Firefox extension
This extension disable 'Secure' & 'HttpOnly' in set-cookie header
 
   
# Compatibility
- Firefox Quantum 48+

# Versions

- 1.0 : Initial release

# Downloads
- [Download with firefox](https://addons.mozilla.org/fr/firefox/addon/set-cookie-no-secure-httponly/)